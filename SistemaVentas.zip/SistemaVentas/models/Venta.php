
<?php
require_once __DIR__ . '/../config/database.php';

class Venta {
    private $db;

    public function __construct() {
        $conexion = new Database();
        $this->db = $conexion->conectar();
    }

    // Registrar una venta
    public function registrar($usuario_id, $carrito) {

        try {

            // Verificar el usuario
            if (!filter_var($usuario_id, FILTER_VALIDATE_INT) || $usuario_id <= 0) {
                throw new Exception("Usuario no válido");
            }

            // Verificar que el carrito no esté vacío
            if (empty($carrito)) {
                throw new Exception("El carrito está vacío");
            }

            $this->db->beginTransaction();

            $total = 0;
            $itemsValidados = [];

            // 1. Verificar productos, precios y stock
            foreach ($carrito as $producto_id => $item) {

                $producto_id = filter_var($producto_id, FILTER_VALIDATE_INT);
                $cantidad = filter_var(
                    $item['cantidad'] ?? null,
                    FILTER_VALIDATE_INT
                );

                if (!$producto_id || !$cantidad || $cantidad < 1) {
                    throw new Exception("Cantidad o producto no válido");
                }

                $stmt = $this->db->prepare(
                    "SELECT id, nombre, precio, stock
                     FROM productos
                     WHERE id = ?
                     FOR UPDATE"
                );

                $stmt->execute([$producto_id]);
                $producto = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$producto) {
                    throw new Exception("Producto no encontrado");
                }

                if ($cantidad > $producto['stock']) {
                    throw new Exception(
                        "Stock insuficiente para: " . $producto['nombre']
                    );
                }

                $subtotal = $producto['precio'] * $cantidad;
                $total += $subtotal;

                $itemsValidados[] = [
                    'producto_id' => $producto_id,
                    'cantidad' => $cantidad,
                    'precio' => $producto['precio'],
                    'subtotal' => $subtotal
                ];
            }

            // 2. Registrar la venta
            $stmt = $this->db->prepare(
                "INSERT INTO ventas (usuario_id, total)
                 VALUES (?, ?)"
            );

            $stmt->execute([$usuario_id, $total]);

            $venta_id = $this->db->lastInsertId();

            // 3. Preparar el registro de detalles
            $stmtDetalle = $this->db->prepare(
                "INSERT INTO detalle_venta
                (venta_id, producto_id, cantidad, precio, subtotal)
                VALUES (?, ?, ?, ?, ?)"
            );

            // 4. Preparar la actualización del stock
            $stmtStock = $this->db->prepare(
                "UPDATE productos
                 SET stock = stock - ?
                 WHERE id = ?"
            );

            // 5. Guardar detalles y actualizar stock
            foreach ($itemsValidados as $item) {

                $stmtDetalle->execute([
                    $venta_id,
                    $item['producto_id'],
                    $item['cantidad'],
                    $item['precio'],
                    $item['subtotal']
                ]);

                $stmtStock->execute([
                    $item['cantidad'],
                    $item['producto_id']
                ]);
            }

            // 6. Confirmar la transacción
            $this->db->commit();

            return [
                'exito' => true,
                'venta_id' => $venta_id,
                'total' => $total
            ];

        } catch (Exception $e) {

            // Deshacer operaciones si ocurre un error
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }

            return [
                'exito' => false,
                'mensaje' => $e->getMessage()
            ];
        }
    }

    // Consultar historial de compras
    public function listarPorUsuario($usuario_id) {

        $sql = "SELECT id, fecha, total
                FROM ventas
                WHERE usuario_id = ?
                ORDER BY fecha DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$usuario_id]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener los detalles de una venta
    public function obtenerDetalle($venta_id, $usuario_id) {

        // Verificar que la venta pertenezca al usuario
        $sql = "SELECT v.id, v.fecha, v.total
                FROM ventas v
                WHERE v.id = ? AND v.usuario_id = ?";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$venta_id, $usuario_id]);

        $venta = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$venta) {
            return null;
        }

        // Consultar los productos de la venta
        $sqlDetalle = "SELECT p.nombre, dv.cantidad,
                       dv.precio, dv.subtotal
                       FROM detalle_venta dv
                       INNER JOIN productos p
                       ON dv.producto_id = p.id
                       WHERE dv.venta_id = ?";

        $stmt = $this->db->prepare($sqlDetalle);
        $stmt->execute([$venta_id]);

        $venta['detalles'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $venta;
    }
}
