<?php
require_once __DIR__ . '/../config/sesion.php';
require_once __DIR__ . '/../models/Producto.php';

class CarritoController {
    private $producto;

    public function __construct() {
        $this->producto = new Producto();
        if (!isset($_SESSION['carrito'])) {
            $_SESSION['carrito'] = [];
        }
    }

    // Agregar un producto
    public function agregar($id, $cantidad) {
        $id = filter_var($id, FILTER_VALIDATE_INT);
        $cantidad = filter_var($cantidad, FILTER_VALIDATE_INT);

        if (!$id || !$cantidad || $cantidad < 1) {
            return "Datos del producto incorrectos";
        }

        $producto = $this->producto->buscarPorId($id);
        if (!$producto) {
            return "El producto no existe";
        }

        $cantidadActual = $_SESSION['carrito'][$id]['cantidad'] ?? 0;
        $nuevaCantidad = $cantidadActual + $cantidad;

        if ($nuevaCantidad > $producto['stock']) {
            return "No hay suficiente stock disponible";
        }

        $_SESSION['carrito'][$id] = [
            'nombre' => $producto['nombre'],
            'precio' => $producto['precio'],
            'cantidad' => $nuevaCantidad
        ];

        return "Producto agregado correctamente";
    }

    // Eliminar un producto
    public function eliminar($id) {
        unset($_SESSION['carrito'][$id]);
    }

    // Vaciar el carrito
    public function vaciar() {
        $_SESSION['carrito'] = [];
    }

    // Calcular el total
    public function calcularTotal() {
        $total = 0;
        foreach ($_SESSION['carrito'] as $item) {
            $total += $item['precio'] * $item['cantidad'];
        }
        return $total;
    }

    // Actualizar cantidad de un producto
    public function actualizarCantidad($id, $cantidad) {
        $id = filter_var($id, FILTER_VALIDATE_INT);
        $cantidad = filter_var($cantidad, FILTER_VALIDATE_INT);

        if (!$id || !$cantidad || $cantidad < 1) {
            return "Cantidad inválida";
        }

        // Verificar que el producto esté en el carrito
        if (!isset($_SESSION['carrito'][$id])) {
            return "El producto no está en el carrito";
        }

        $producto = $this->producto->buscarPorId($id);
        if (!$producto) {
            return "El producto no existe";
        }

        if ($cantidad > $producto['stock']) {
            return "No hay suficiente stock disponible";
        }

        $_SESSION['carrito'][$id]['cantidad'] = $cantidad;
        return "Cantidad actualizada correctamente";
    }
}