<?php
require_once __DIR__ . '/../config/sesion.php';
require_once __DIR__ . '/../models/Venta.php';
require_once __DIR__ . '/../controllers/CarritoController.php';

class VentaController {
    private $venta;

    public function __construct() {
        $this->venta = new Venta();
    }

    public function confirmar() {
        verificarSesion();

        if (empty($_SESSION['carrito'])) {
            return ['exito' => false, 'mensaje' => 'El carrito está vacío'];
        }

        $resultado = $this->venta->registrar(
            $_SESSION['usuario_id'],
            $_SESSION['carrito']
        );

        if ($resultado['exito']) {
            // Vaciar el carrito
            $carrito = new CarritoController();
            $carrito->vaciar();
        }

        return $resultado;
    }

    public function historial() {
        verificarSesion();
        return $this->venta->listarPorUsuario($_SESSION['usuario_id']);
    }

    public function detalle($venta_id) {
        verificarSesion();
        return $this->venta->obtenerDetalle($venta_id, $_SESSION['usuario_id']);
    }
}