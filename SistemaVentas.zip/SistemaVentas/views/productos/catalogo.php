
<link rel="stylesheet" href="public/css/estilos.css">

<div class="tienda">

    <!-- BARRA SUPERIOR -->
    <header class="barra-tienda">
        <h2>TECNO STORE</h2>

        <nav class="menu-tienda">
            <span>
                Hola, <strong><?= htmlspecialchars($_SESSION['nombre']) ?></strong>
            </span>

            <a href="index.php?ruta=carrito">Mi carrito</a>
            <a href="index.php?ruta=historial">Mis compras</a>
            <a href="logout.php">Cerrar sesión</a>
        </nav>
    </header>

    <!-- PRESENTACIÓN -->
    <section class="presentacion-tienda">
        <h1>Encuentra lo que necesitas</h1>
        <p>Explora nuestros productos y realiza tus compras fácilmente.</p>
    </section>

    <!-- CATÁLOGO -->
    <main class="catalogo-tienda">

        <div class="titulo-catalogo">
            <h2>Nuestros productos</h2>
            <p>Descubre todo lo que tenemos para ti</p>
        </div>

        <div class="productos">

            <?php foreach ($productos as $p): ?>

                <div class="producto">

                    <div class="icono-producto">
                        <span>PRODUCTO</span>
                    </div>

                    <div class="info-producto">

                        <h3><?= htmlspecialchars($p['nombre']) ?></h3>

                        <p class="descripcion-producto">
                            <?= htmlspecialchars($p['descripcion']) ?>
                        </p>

                        <p class="precio-producto">
                            S/ <?= number_format($p['precio'], 2) ?>
                        </p>

                        <p class="stock-producto">
                            Stock disponible: <?= $p['stock'] ?>
                        </p>

                        <form method="POST" action="index.php?ruta=agregar">

                            <input type="hidden" name="producto_id"
                                   value="<?= $p['id'] ?>">

                            <label>Cantidad:</label>

                            <input type="number" name="cantidad"
                                   value="1" min="1"
                                   max="<?= $p['stock'] ?>" required>

                            <button type="submit"
                                    <?= $p['stock'] <= 0 ? 'disabled' : '' ?>>
                                <?= $p['stock'] <= 0 ? 'Sin stock' : 'Agregar al carrito' ?>
                            </button>

                        </form>

                    </div>
                </div>

            <?php endforeach; ?>

        </div>

    </main>

    <!-- PIE DE PÁGINA -->
    <footer class="pie-tienda">
        <p>TECNO STORE | Tu tienda virtual</p>
    </footer>

</div>
