<link rel="stylesheet" href="public/css/estilos.css">

<div class="container">
    <h2>Crear cuenta</h2>

    <?php if (isset($mensaje)): ?>
        <div class="<?= strpos($mensaje, 'correctamente') !== false ? 'mensaje-exito' : 'mensaje-error' ?>">
            <?= htmlspecialchars($mensaje) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="index.php?ruta=registro">
        <label>Nombre completo</label>
        <input type="text" name="nombre" required>

        <label>Correo electrónico</label>
        <input type="email" name="correo" required>

        <label>Contraseña</label>
        <input type="password" name="password" minlength="8" required>

        <button type="submit">Registrarme</button>
    </form>

    <p style="text-align:center; margin-top:15px;">
        <a href="index.php?ruta=login">Ya tengo una cuenta</a>
    </p>
</div>