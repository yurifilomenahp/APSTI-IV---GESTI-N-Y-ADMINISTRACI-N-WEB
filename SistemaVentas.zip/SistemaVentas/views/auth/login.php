<link rel="stylesheet" href="public/css/estilos.css">

<div class="container">
    <h2>Iniciar sesión</h2>

    <?php if (isset($mensaje)): ?>
        <div class="mensaje-error">
            <?= htmlspecialchars($mensaje) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="index.php?ruta=login">
        <label>Correo electrónico</label>
        <input type="email" name="correo" required>

        <label>Contraseña</label>
        <input type="password" name="password" required>

        <button type="submit">Ingresar</button>
    </form>

    <p style="text-align:center; margin-top:15px;">
        <a href="index.php?ruta=registro">Crear una cuenta</a>
    </p>
</div>