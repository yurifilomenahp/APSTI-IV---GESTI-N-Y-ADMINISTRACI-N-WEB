
<link rel="stylesheet" href="public/css/estilos.css">

<div class="container pagina-tienda">

    <div class="encabezado-pagina">
        <div>
            <h2>Historial de compras</h2>
            <p>Consulta los productos que has comprado anteriormente.</p>
        </div>
        <span class="etiqueta-tienda">TECNO STORE</span>
    </div>

    <div class="navegacion-tienda">
        <a href="index.php?ruta=catalogo">← Volver al catálogo</a>
        <a href="index.php?ruta=carrito">Ver carrito</a>
        <a href="logout.php">Cerrar sesión</a>
    </div>

    <?php if (empty($ventas)): ?>

        <div class="carrito-vacio">
            <h3>Aún no tienes compras</h3>
            <p>Cuando realices una compra, aparecerá aquí tu historial.</p>
            <a href="index.php?ruta=catalogo" class="btn-primario">
                Explorar productos
            </a>
        </div>

    <?php else: ?>

        <?php foreach ($ventas as $venta): ?>

            <div class="tarjeta-venta">

                <div class="cabecera-venta">
                    <div>
                        <span class="texto-secundario">Número de compra</span>
                        <h3>Venta #<?= $venta['id'] ?></h3>
                    </div>

                    <div>
                        <span class="texto-secundario">Fecha de compra</span>
                        <p><?= date('d/m/Y H:i', strtotime($venta['fecha'])) ?></p>
                    </div>

                    <div class="total-venta">
                        <span class="texto-secundario">Total pagado</span>
                        <strong>S/ <?= number_format($venta['total'], 2) ?></strong>
                    </div>
                </div>

                <?php
                // Cargar detalle de la venta
                $detalle = $ventaController->detalle($venta['id']);
                ?>

                <?php if ($detalle && !empty($detalle['detalles'])): ?>

                    <div class="tabla-contenedor">
                        <table class="tabla-detalle">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Cantidad</th>
                                    <th>Precio unitario</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($detalle['detalles'] as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['nombre']) ?></td>
                                    <td><?= $item['cantidad'] ?></td>
                                    <td>S/ <?= number_format($item['precio'], 2) ?></td>
                                    <td>S/ <?= number_format($item['subtotal'], 2) ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                <?php endif; ?>

            </div>

        <?php endforeach; ?>

    <?php endif; ?>

</div>
