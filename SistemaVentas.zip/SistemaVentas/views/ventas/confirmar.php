<link rel="stylesheet" href="public/css/estilos.css">

<div class="container">
    <h2>Confirmación de compra</h2>

    <?php if (isset($resultado) && $resultado['exito']): ?>
        <div class="mensaje-exito">
            <h3>¡Compra realizada con éxito!</h3>
            <p>Número de venta: <strong>#<?= $resultado['venta_id'] ?></strong></p>
            <p>Total pagado: <strong>S/ <?= number_format($resultado['total'], 2) ?></strong></p>
        </div>
        <div class="botones-carrito" style="justify-content: flex-start;">
            <a href="index.php?ruta=historial" class="btn-primario">Ver mi historial</a>
            <a href="index.php?ruta=catalogo" class="btn-secundario">Seguir comprando</a>
        </div>
    <?php else: ?>
        <div class="mensaje-error">
            <p><?= htmlspecialchars($resultado['mensaje'] ?? 'Error al procesar la compra') ?></p>
        </div>
        <a href="index.php?ruta=carrito" class="btn-secundario">Volver al carrito</a>
    <?php endif; ?>
</div>