
<link rel="stylesheet" href="public/css/estilos.css">

<div class="container pagina-tienda">

    <div class="encabezado-pagina">
        <div>
            <h2>Mi carrito de compras</h2>
            <p>Revisa tus productos antes de confirmar tu compra.</p>
        </div>
        <span class="etiqueta-tienda">TECNO STORE</span>
    </div>

    <div class="navegacion-tienda">
        <a href="index.php?ruta=catalogo">← Seguir comprando</a>
        <a href="index.php?ruta=historial">Mis compras</a>
        <a href="logout.php">Cerrar sesión</a>
    </div>

    <?php if (empty($_SESSION['carrito'])): ?>

        <div class="carrito-vacio">
            <h3>Tu carrito está vacío</h3>
            <p>¡Explora nuestro catálogo y encuentra lo que necesitas!</p>
            <a href="index.php?ruta=catalogo" class="btn-primario">
                Ir al catálogo
            </a>
        </div>

    <?php else: ?>

        <div class="tabla-contenedor">
            <table class="tabla-tienda">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Subtotal</th>
                        <th>Acción</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($_SESSION['carrito'] as $id => $item): ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars($item['nombre']) ?></strong>
                        </td>

                        <td>
                            S/ <?= number_format($item['precio'], 2) ?>
                        </td>

                        <td>
                            <form method="POST"
                                  action="index.php?ruta=actualizar"
                                  class="form-cantidad">

                                <input type="hidden"
                                       name="producto_id"
                                       value="<?= $id ?>">

                                <input type="number"
                                       name="cantidad"
                                       value="<?= $item['cantidad'] ?>"
                                       min="1"
                                       required>

                                <button type="submit" class="btn-pequeno">
                                    Actualizar
                                </button>
                            </form>
                        </td>

                        <td>
                            <strong>
                                S/ <?= number_format($item['precio'] * $item['cantidad'], 2) ?>
                            </strong>
                        </td>

                        <td>
                            <a href="index.php?ruta=eliminar&id=<?= $id ?>"
                               class="btn-eliminar">
                                Eliminar
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="resumen-carrito">
            <p>Total de tu compra</p>

            <h2>S/ <?= number_format($total, 2) ?></h2>

            <div class="botones-carrito">
                <a href="index.php?ruta=vaciar" class="btn-secundario">
                    Vaciar carrito
                </a>

                <a href="index.php?ruta=confirmar" class="btn-primario">
                    Confirmar compra
                </a>
            </div>
        </div>

    <?php endif; ?>

</div>
