<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar si existe un usuario autenticado
function verificarSesion() {
    if (!isset($_SESSION['usuario_id'])) {
        header("Location: index.php?ruta=login");
        exit;
    }
}

// Obtener el nombre del usuario
function obtenerNombreUsuario() {
    return $_SESSION['nombre'] ?? 'Invitado';
}